#ifndef triangles_hpp
#define triangles_hpp

struct tex1{
	int p1[2]={0,0};	
	int p2[2]={180,0};
	int p3[2]={180,180};
	int p4[2]={0,180};	
}tex1;

struct tex2{
	int p1[2]={0,0};	
	int p2[2]={265,0};
	int p3[2]={265,380};
	int p4[2]={0,380};	
}tex2;

struct tex3{
	int p1[2]={0,0};	
	int p2[2]={135,0};
	int p3[2]={135,380};
	int p4[2]={0,380};	
}tex3;

struct tex4{
	int p1[2]={0,0};	
	int p2[2]={135,0};
	int p3[2]={135,125};
	int p4[2]={0,125};	
}tex4;

struct tex5{
	int p1[2]={0,0};	
	int p2[2]={125,0};
	int p3[2]={125,380};
	int p4[2]={0,380};	
}tex5;


#endif

